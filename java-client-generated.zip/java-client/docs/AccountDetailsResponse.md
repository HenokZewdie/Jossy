
# AccountDetailsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creditCardAccount** | [**CreditCardAccount**](CreditCardAccount.md) |  |  [optional]
**readyCreditAccount** | [**ReadyCreditAccount**](ReadyCreditAccount.md) |  |  [optional]
**checkingAccount** | [**CheckingAccount**](CheckingAccount.md) |  |  [optional]
**savingsAccount** | [**SavingsAccount**](SavingsAccount.md) |  |  [optional]
**timeDepositAccount** | [**TimeDepositAccount**](TimeDepositAccount.md) |  |  [optional]
**loanAccount** | [**LoanAccount**](LoanAccount.md) |  |  [optional]
**mutualFundAccount** | [**MutualFundAccount**](MutualFundAccount.md) |  |  [optional]
**securitiesBrokerageAccount** | [**SecuritiesBrokerageAccount**](SecuritiesBrokerageAccount.md) |  |  [optional]
**callDepositAccount** | [**CallDepositAccount**](CallDepositAccount.md) |  |  [optional]
**premiumDepositAccount** | [**PremiumDepositAccount**](PremiumDepositAccount.md) |  |  [optional]



