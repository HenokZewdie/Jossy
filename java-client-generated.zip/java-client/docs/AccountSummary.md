
# AccountSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**checkingAccountSummary** | [**CheckingAccountSummary**](CheckingAccountSummary.md) |  |  [optional]
**savingsAccountSummary** | [**SavingsAccountSummary**](SavingsAccountSummary.md) |  |  [optional]
**creditCardAccountSummary** | [**CreditCardAccountSummary**](CreditCardAccountSummary.md) |  |  [optional]
**readyCreditAccountSummary** | [**ReadyCreditAccountSummary**](ReadyCreditAccountSummary.md) |  |  [optional]
**loanAccountSummary** | [**LoanAccountSummary**](LoanAccountSummary.md) |  |  [optional]
**mutualFundAccountSummary** | [**MutualFundAccountSummary**](MutualFundAccountSummary.md) |  |  [optional]
**securitiesBrokerageAccountSummary** | [**SecuritiesBrokerageAccountSummary**](SecuritiesBrokerageAccountSummary.md) |  |  [optional]
**callDepositAccountSummary** | [**CallDepositAccountSummary**](CallDepositAccountSummary.md) |  |  [optional]
**premiumDepositAccountSummary** | [**PremiumDepositAccountSummary**](PremiumDepositAccountSummary.md) |  |  [optional]
**timeDepositAccountSummary** | [**TimeDepositAccountSummary**](TimeDepositAccountSummary.md) |  |  [optional]



