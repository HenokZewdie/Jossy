
# Relationship

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**relationshipName** | **String** | The relationship name for a customer |  [optional]
**relationshipType** | **String** | This is a reference data field. Please use /v1/apac/utilities/referenceData/{relationshipType} resource to get valid value of this field with description. You can use the field name as the referenceCode parameter to retrieve the values. |  [optional]



